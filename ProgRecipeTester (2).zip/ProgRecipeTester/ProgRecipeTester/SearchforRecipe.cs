﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgRecipeTester
{
    public partial class SearchforRecipe : Form
    {
        public SearchforRecipe()
        {
            InitializeComponent();
        }

        private void lblSearchRecipe_Click(object sender, EventArgs e)
        {

        }
    }
}
