﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgRecipeTester
{
    public class StepsClass
    {

        public string Steps {  get; set; }


        public StepsClass(string steps) 
        {
            Steps = steps;
        }

    }
}
